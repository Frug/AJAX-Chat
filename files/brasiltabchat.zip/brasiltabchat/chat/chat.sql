DROP TABLE IF EXISTS ajax_chat_online;
CREATE TABLE ajax_chat_online (
	userID INT(11) NOT NULL,
	userName VARCHAR(64) NOT NULL,
	userRole INT(1) NOT NULL,
	channel INT(11) NOT NULL,
	dateTime DATETIME NOT NULL,
	ip VARBINARY(16) NOT NULL
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS ajax_chat_messages;
CREATE TABLE ajax_chat_messages (
	id INT(11) NOT NULL AUTO_INCREMENT,
	userID INT(11) NOT NULL,
	fontColor varchar(20) NOT NULL default '',
	fontStyle enum('normal','italic','oblique') NOT NULL default 'normal',
	fontWeight enum('normal','lighter','bold','bolder') NOT NULL default 'normal',
	fontDecoration enum('none','underline','line-through','overline') NOT NULL default 'none',
	userName VARCHAR(64) NOT NULL,
	receiverName varchar(64) NOT NULL,
	userAvatar varchar(255) NOT NULL,
	userRole INT(1) NOT NULL,
	channel INT(11) NOT NULL,
	dateTime DATETIME NOT NULL,
	ip VARBINARY(16) NOT NULL,
	text TEXT,
	msgread enum('yes','no') NOT NULL default 'yes',
	PRIMARY KEY (id)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS ajax_chat_bans;
CREATE TABLE ajax_chat_bans (
	userID INT(11) NOT NULL,
	userName VARCHAR(64) NOT NULL,
	dateTime DATETIME NOT NULL,
	ip VARBINARY(16) NOT NULL
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS ajax_chat_invitations;
CREATE TABLE ajax_chat_invitations (
	userID INT(11) NOT NULL,
	channel INT(11) NOT NULL,
	dateTime DATETIME NOT NULL
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS ajax_chat_istyping;
CREATE TABLE ajax_chat_istyping (
	id INT(11) NOT NULL AUTO_INCREMENT,
	userName1 varchar(64) NOT NULL,
	userIsTyping1 enum('yes','no') NOT NULL default 'no',
	userName2 varchar(64) NOT NULL,
	userIsTyping2 enum('yes','no') NOT NULL default 'no',
	PRIMARY KEY  (id)
) DEFAULT CHARSET=utf8 COLLATE=utf8_bin;