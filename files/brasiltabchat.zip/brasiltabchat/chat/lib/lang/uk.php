<?php
/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @author Yuriy Smetana (yura@stryi.com.ua, http://joomla.org.ua)
 * @copyright (c) Sebastian Tschan
 * @license GNU Affero General Public License
 * @link https://blueimp.net/ajax/
 */

$lang = array();

// NEW VARS IN TABBED CHAT MOD - INI

$lang['changeCustomFontColor'] = '(Change)';
$lang['fontColorLabel'] = 'Font Color:';
$lang['fontStyleLabel'] = 'Font Style:';
$lang['fontStyleNormal'] = 'Normal';
$lang['fontStyleItalic'] = 'Italic';
$lang['fontStyleOblique'] = 'Oblique';
$lang['fontWeightLabel'] = 'Font Weight:';
$lang['fontWeightNormal'] = 'Normal';
$lang['fontWeightLighter'] = 'Lighter';
$lang['fontWeightBold'] = 'Bold';
$lang['fontWeightBolder'] = 'Bolder';
$lang['fontDecorationLabel'] = 'Font Decoration:';
$lang['fontDecorationNone'] = 'None';
$lang['fontDecorationUnderline'] = 'Underline';
$lang['fontDecorationLineThrough'] = 'Line-Through';
$lang['fontDecorationOverline'] = 'Overline';
$lang['audioLocationLabel'] = 'Sound Locations:';
$lang['audioLocationAll'] = 'All';
$lang['audioLocationMain'] = 'Main Chat';
$lang['audioLocationTabs'] = 'Private Tabs';

// NEW VARS IN TABBED CHAT MOD - END

$lang['title'] = 'AJAX Chat';
$lang['userName'] = 'Ім\'я користувача';
$lang['password'] = 'Пароль';
$lang['login'] = 'Увійти';
$lang['logout'] = 'Вийти';
$lang['channel'] = 'Кімната';
$lang['style'] = 'Стиль';
$lang['language'] = 'Мова';
$lang['inputLineBreak'] = 'Використовуйте SHIFT+ENTER для нового рядка';
$lang['messageSubmit'] = 'Надіслати';
$lang['registeredUsers'] = 'Зареєстровані користувачі';
$lang['onlineUsers'] = 'Зараз в Чаті';
$lang['toggleAutoScroll'] = 'Прогортувати: так/ні';
$lang['toggleAudio'] = 'Звік: так/ні';
$lang['toggleHelp'] = 'Показати допомогу: так/ні';
$lang['toggleSettings'] = 'Показати налаштування: так/ні';
$lang['toggleOnlineList'] = 'Хто в Чаті: так/ні';
$lang['bbCodeLabelBold'] = 'Ж';
$lang['bbCodeLabelItalic'] = 'Н';
$lang['bbCodeLabelUnderline'] = 'П';
$lang['bbCodeLabelQuote'] = 'Цитата';
$lang['bbCodeLabelCode'] = 'Код';
$lang['bbCodeLabelURL'] = 'URL';
$lang['bbCodeLabelImg'] = 'Image';
$lang['bbCodeLabelColor'] = 'Колір шрифту';
$lang['bbCodeTitleBold'] = 'Жирний текст: [b]текст[/b]';
$lang['bbCodeTitleItalic'] = 'Текст курсивом: [i]текст[/i]';
$lang['bbCodeTitleUnderline'] = 'Підкреслений текст: [u]текст[/u]';
$lang['bbCodeTitleQuote'] = 'Цитований текст: [quote]текст[/quote] чи [quote=author]текст[/quote]';
$lang['bbCodeTitleCode'] = 'Показати код: [code]код[/code]';
$lang['bbCodeTitleURL'] = 'Показати URL: [url]http://example.org[/url] or [url=http://example.org]текст[/url]';
$lang['bbCodeTitleImg'] = 'Insert image: [img]http://example.org/image.jpg[/img]';
$lang['bbCodeTitleColor'] = 'Колір шрифту: [color=red]текст[/color]';
$lang['help'] = 'Допомога';
$lang['helpItemDescJoin'] = 'Зайти в кімнату:';
$lang['helpItemCodeJoin'] = '/join Назва_Кімнати';
$lang['helpItemDescJoinCreate'] = 'Створити приватну кімнату (тільки для зареєстрованих користувачів):';
$lang['helpItemCodeJoinCreate'] = '/join';
$lang['helpItemDescInvite'] = 'Запросити когось (наприклад до приватної кімнати):';
$lang['helpItemCodeInvite'] = '/invite Користувач';
$lang['helpItemDescUninvite'] = 'Відмінити запрошення:';
$lang['helpItemCodeUninvite'] = '/uninvite Користувач';
$lang['helpItemDescLogout'] = 'Вийти з чату:';
$lang['helpItemCodeLogout'] = '/quit';
$lang['helpItemDescPrivateMessage'] = 'Приватне повідомлення:';
$lang['helpItemCodePrivateMessage'] = '/msg Користувач Текст';
$lang['helpItemDescQueryOpen'] = 'Створити приватну кімнату:';
$lang['helpItemCodeQueryOpen'] = '/query Користувач';
$lang['helpItemDescQueryClose'] = 'Закрити приватну кімнату:';
$lang['helpItemCodeQueryClose'] = '/query';
$lang['helpItemDescAction'] = 'Описати чим займаєтесь:';
$lang['helpItemCodeAction'] = '/action Що Робите';
$lang['helpItemDescDescribe'] = 'Описати чим займаєтесь, в приватному повідомленні:';
$lang['helpItemCodeDescribe'] = '/describe Кому   Що Робите';
$lang['helpItemDescIgnore'] = 'Ігнорувати/приймати повідомлення від користувача:';
$lang['helpItemCodeIgnore'] = '/ignore Користувач';
$lang['helpItemDescIgnoreList'] = 'Перелік ігнорованих користувачів:';
$lang['helpItemCodeIgnoreList'] = '/ignore';
$lang['helpItemDescWhereis'] = 'Показати кімнату користувача:';
$lang['helpItemCodeWhereis'] = '/whereis Користувач';
$lang['helpItemDescKick'] = 'Вигнати користувача (тільки для модераторів):';
$lang['helpItemCodeKick'] = '/kick Користувач [на скільки хвилин]';
$lang['helpItemDescUnban'] = 'Розблокувати користувача (тільки для модераторів):';
$lang['helpItemCodeUnban'] = '/unban Користувач';
$lang['helpItemDescBans'] = 'Перелік заблокованих користувачів:';
$lang['helpItemCodeBans'] = '/bans';
$lang['helpItemDescWhois'] = 'Показати ІР користувача (тільки для модераторів):';
$lang['helpItemCodeWhois'] = '/whois Користувач';
$lang['helpItemDescWho'] = 'Хто в Чаті:';
$lang['helpItemCodeWho'] = '/who [Кімната]';
$lang['helpItemDescList'] = 'Перелік кімнат:';
$lang['helpItemCodeList'] = '/list';
$lang['helpItemDescRoll'] = 'Кинути кості:';
$lang['helpItemCodeRoll'] = '/roll [к-сть]d[к-сть сторін]';
$lang['helpItemDescNick'] = 'Змінити ім\'я користувача:';
$lang['helpItemCodeNick'] = '/nick Користувач';
$lang['settings'] = 'Налаштування';
$lang['settingsBBCode'] = 'Дозволити коди BB:';
$lang['settingsBBCodeImages'] = 'Enable image BBCode:';
$lang['settingsBBCodeColors'] = 'Enable font color BBCode:';
$lang['settingsHyperLinks'] = 'Дозволити посилання:';
$lang['settingsLineBreaks'] = 'Дозволити багаторядковість:';
$lang['settingsEmoticons'] = 'Дозволити хихоньки:';
$lang['settingsAutoFocus'] = 'Автоматично встановлювати фокус на полі вводу:';
$lang['settingsMaxMessages'] = 'Максимальна кількість повідомлень у вікні Чату:';
$lang['settingsWordWrap'] = 'Розділювати довгі слова:';
$lang['settingsMaxWordLength'] = 'Максимальна довжина слова після якої його буде розділено:';
$lang['settingsDateFormat'] = 'Формат дати та часу:';
$lang['settingsPersistFontColor'] = 'Колір для привернення уваги:';
$lang['settingsAudioVolume'] = 'Гучність:';
$lang['settingsSoundReceive'] = 'Звук для отриманих повідомлень:';
$lang['settingsSoundSend'] = 'Звук для надісланих повідомлень:';
$lang['settingsSoundEnter'] = 'Звук для події входу в Чат чи кімнату:';
$lang['settingsSoundLeave'] = 'Звук для події виходу з Чату чи кімнати:';
$lang['settingsSoundChatBot'] = 'Звук для системних повідомлень:';
$lang['settingsSoundError'] = 'Звук для помилок:';
$lang['settingsBlink'] = 'Сигналізувати при появі нових повідомлень (блимання заголовку вікна):';
$lang['settingsBlinkInterval'] = 'Тривалість блимання заголовку вікна:';
$lang['settingsBlinkIntervalNumber'] = 'Кількість блимань:';
$lang['playSelectedSound'] = 'Відтворити обраний звук';
$lang['requiresJavaScript'] = 'Для цього Чату потрібно дозволити JavaScript.';
$lang['errorInvalidUser'] = 'Неправильне ім\'я користувача.';
$lang['errorUserInUse'] = 'Таке ім\'я вже використовується';
$lang['errorBanned'] = 'Користувач або IP заблокований.';
$lang['errorMaxUsersLoggedIn'] = 'В Чаті максимальна кількість учасників.';
$lang['errorChatClosed'] = 'Чат, тимчасово, закрито.';
$lang['logsTitle'] = 'AJAX Chat - Logs';
$lang['logsDate'] = 'Дата';
$lang['logsTime'] = 'Час';
$lang['logsSearch'] = 'Пошук';
$lang['logsPrivateChannels'] = 'Приватні кімнати';
$lang['logsPrivateMessages'] = 'Приватні повідомлення';
?>