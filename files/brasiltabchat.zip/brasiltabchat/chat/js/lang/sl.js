/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @author Valter Pepelko?
 * @copyright (c) Sebastian Tschan
 * @license GNU Affero General Public License
 * @link https://blueimp.net/ajax/
 */

// Ajax Chat language Object:
var ajaxChatLang = {

	// NEW VARS IN TABBED CHAT MOD - INI

	userIsTyping: '%s is typing...',
	openTabbedChatWith: 'Open Tabbed Chat with %s',
	openTabbedChat: 'Open Private Chat Tab',
	whisperChatWith: 'Privately whisper to %s',
	quoteChatWith: 'Quote User %s',

	insertPersonalizedColor: 'Insert Custom Color',
	cleanFontClor: 'Clean Font Color',
	personalizedColorPrompt: 'Enter the custom color (format: #FFFFFF):',

	// NEW VARS IN TABBED CHAT MOD - END

	login: '%s prijavljen-a na Klepetu.',
	logout: '%s odjavljen-a iz Klepeta.',
	logoutTimeout: '%s je prijava potekla (Timeout).',
	logoutIP: '%s je prijava potekla (Nepopolna IP adresa).',
	logoutKicked: '%s je prijava potekla (Kicked).',
	channelEnter: '%s je vstopil-a v sobo.',
	channelLeave: '%s od??el-a iz sobe.',
	privmsg: '(privatno sporo�?ilo)',
	privmsgto: '(se privatno pogovarja z %s)',
	invite: '%s vas vabi na razgovor v %s.',
	inviteto: 'Va??e vabilo za razgovor z %s v sobi %s je poslano.',
	uninvite: '%s se ne ??eli odzvati va??emu vabilu v sobi %s.',
	uninviteto: 'Va?? preklic vabila za %s v sobi %s je poslano.',
	queryOpen: 'Privatna soba za %s je odprta.',
	queryClose: 'Privatna soba za %s je zaprta.',
	ignoreAdded: '%s je dodan na seznam ignoriranih.',
	ignoreRemoved: '%s je odstranjen iz seznama ignoriranih.',
	ignoreList: 'Ignorirani uporabniki:',
	ignoreListEmpty: 'Seznam ignoriranih uporabnikov je prazen.',
	who: 'Prisotni:',
	whoChannel: 'Prisotni v sobi %s:',
	whoEmpty: 'V tej sobi ni uporabnikov.',
	list: 'Dostopne sobe:',
	bans: 'Uporabniki s prepovedjo dostopa:',
	bansEmpty: 'Seznam uporabnikov s prepovedjo dostopa je prazen.',
	unban: 'Prepoved dostopa uporabniku je preklicana.',
	whois: 'Uporabnik %s - IP adresa:',
	whereis: 'Uporabnik %s je v sobi %s.',
	roll: '%s je vrgel %s Rezultat je: %s.',
	nick: '%s sedaj uporablja nick %s.',
	toggleUserMenu: 'Preklopi uporabni??ki meni za %s',
	userMenuLogout: 'Odjava',
	userMenuWho: 'Seznam prisotnih uporabnikov',
	userMenuList: 'Seznam dostopnih sob',
	userMenuAction: 'Opi??i akcijo',
	userMenuRoll: 'Vrzi kocko',
	userMenuNick: 'Zamenjaj uporabni??ko ime',
	userMenuEnterPrivateRoom: 'Vstopi v privatno sobo',
	userMenuSendPrivateMessage: 'Po??lji privatno sporo�?ilo',
	userMenuDescribe: 'Po??lji privatno akcijo',
	userMenuOpenPrivateChannel: 'Odpri privatno sobo',
	userMenuClosePrivateChannel: 'Zapri privatno sobo',
	userMenuInvite: 'Poklicati',
	userMenuUninvite: 'Preklicati',
	userMenuIgnore: 'Ignoriraj/Sprejemi',
	userMenuIgnoreList: 'Seznam ignoriranih uporabnikov',
	userMenuWhereis: 'Prika??i sobo',
	userMenuKick: 'Izvr??een/Prepovedan',
	userMenuBans: 'Seznam prepovedanih uporabnikov',
	userMenuWhois: 'Prika??i IP adreso',
	unbanUser: 'Preklicati prepoved uporabniku %s',
	joinChannel: 'Vstopi v sobo %s',
	cite: '%s pravi:',
	urlDialog: 'Prosimo vas, vnesite naslov (URL) web strani:',
	deleteMessage: 'Izbri??i to sporo�?ilo',
	deleteMessageConfirm: 'Ali res izbri??em izbrano sporo�?ilo?',
	errorCookiesRequired: 'Pozor: uporaba pi??kotkov (cookies) je nujna za to klepetalnico!',
	errorUserNameNotFound: 'Napaka: uporabnik %s ni najden!',
	errorMissingText: 'Napaka: manjka besedilo sporo�?ila!',
	errorMissingUserName: 'Napaka: manjka uporabni??ko ime!',
	errorInvalidUserName: 'Napaka: Nepravilno uporabni??ko ime!',
	errorUserNameInUse: 'Napaka: uporabni??ko ime je ??e v uporabi!',
	errorMissingChannelName: 'Napaka: ni imena sobe!',
	errorInvalidChannelName: 'Napaka: napa�?no ime sobe: %s',
	errorPrivateMessageNotAllowed: 'Napaka: privatna sporo�?ila niso dovoljena!',
	errorInviteNotAllowed: 'Napaka: Nimate dovoljenja, da lahko druge vabite v to sobo!',
	errorUninviteNotAllowed: 'Napaka: Nimate dovoljenja, da lahko druge vr??ete iz te sobe!',
	errorNoOpenQuery: 'Napaka: Privatna soba ni odprta!',
	errorKickNotAllowed: 'NApaka: Nimate dovoljenja, da lahko vr??ete %s',
	errorCommandNotAllowed: 'Napaka: Ukaz ni dozvoljen: %s',
	errorUnknownCommand: 'Napaka: Neznan ukaz: %s',
	errorMaxMessageRate: 'NApaka: Presegli ste najve�?je dovoljeno ??tevilo sporo�?il na minuto!.',
	errorConnectionTimeout: 'Napaka: �?as povezave se je iztekel. Poskusite znova!',
	errorConnectionStatus: 'Napaka: Status povezave: %s',
	errorSoundIO: 'Napaka: Zvo�?ne datoteke ni bilo mogo�?e nalo??iti (Napaka Flash IO)!',
	errorSocketIO: 'Napaka: Povezava na server ni uspela (Napaka Flash IO)!',
	errorSocketSecurity: 'Napaka: Povezava na server ni uspela (Napaka Flash Security)!',
	errorDOMSyntax: 'Napaka: Nepopolna DOM Syntaxa (DOM ID: %s).'
	
}