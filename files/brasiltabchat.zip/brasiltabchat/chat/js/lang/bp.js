/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @author vitoalvaro - modified by bccsergio
 * @copyright (c) Sebastian Tschan
 * @license GNU Affero General Public License
 * @link https://blueimp.net/ajax/
 */

// Ajax Chat language Object:
var ajaxChatLang = {

	// NEW VARS IN TABBED CHAT MOD - INI

	userIsTyping: '%s está digitando...',
	openTabbedChatWith: 'Abrir Conversa Privada com %s',
	openTabbedChat: 'Abrir Aba de Chat Privado',
	whisperChatWith: 'Sussurrar Reservadamente para %s',
	quoteChatWith: 'Citar Usuário %s',

	insertPersonalizedColor: 'Inserir Cor Personalizada',
	cleanFontClor: 'Limpar Cor da Fonte',
	personalizedColorPrompt: 'Digite a cor personalizada (formato: #FFFFFF):',

	// NEW VARS IN TABBED CHAT MOD - END	

	login: '%s acaba de entrar no Chat.',
	logout: '%s acaba de sair do Chat.',
	logoutTimeout: '%s desconectou (Tempo esgotado).',
	logoutIP: '%s desconectou (Endereço de IP inválido).',
	logoutKicked: '%s desconectou (Expulso do canal).',
	channelEnter: '%s entrou no canal.',
	channelLeave: '%s saiu do canal.',
	privmsg: '(Sussurra reservadamente para você)',
	privmsgto: '(Sussurra reservadamente para %s)',
	invite: '%s convida você para participar %s.',
	inviteto: 'O seu convite para se juntar ao %s do canal %s foi enviado.',
	uninvite: '%s desconvidou você do canal %s.',
	uninviteto: 'Seu desconvidamento %s do canal %s foi enviada.',	
	queryOpen: 'Canal privado aberto para %s.',
	queryClose: 'Canal privado para %s fechado.',
	ignoreAdded: '%s adicionado na lista de igrnorados.',
	ignoreRemoved: '%s removido da lista de ignorados.',
	ignoreList: 'Usuários ignorados:',
	ignoreListEmpty: 'Nenhum usuário na lista de ignorados.',
	who: 'Usuários Online:',
	whoChannel: 'Usuários online no canal %s:',
	whoEmpty: 'Nenhum usuário online no determinado canal.',
	list: 'Os canais disponíveis:',
	bans: 'Usuários banidos:',
	bansEmpty: 'Nenhum usuário na lista de banidos.',
	unban: 'Banimento do usuário %s revogado.',
	whois: 'Usuário %s - enderenço IP:',
	whereis: 'Usuário %s está no canal %s.',
	roll: '%s joga dados %s e tira %s.',
	nick: '%s é agora conhecido como %s.',
	toggleUserMenu: 'Alternar menu para o usuário %s',
	userMenuLogout: 'Deslogar',
	userMenuWho: 'Lista de usuários online',
	userMenuList: 'Lista de canais disponíveis',
	userMenuAction: 'Descreva ação',
	userMenuRoll: 'Jogar dados',
	userMenuNick: 'Trocar usuário',
	userMenuEnterPrivateRoom: 'Entrar sala privada',
	userMenuSendPrivateMessage: 'Sussurar reservadamente',
	userMenuDescribe: 'Enviar ação privada',
	userMenuOpenPrivateChannel: 'Abrir canal privado',
	userMenuClosePrivateChannel: 'Fechar canal privado',
	userMenuInvite: 'Convidar',
	userMenuUninvite: 'Desconvidar',
	userMenuIgnore: 'Ignorar/Aceitar',
	userMenuIgnoreList: 'Lista de usuários ignorados',
	userMenuWhereis: 'Exibir canais',
	userMenuKick: 'Kickar/Banir',
	userMenuBans: 'Lista de usuários banidos',
	userMenuWhois: 'Exibir IP',
	unbanUser: 'Revogar banimento do usuário %s',
	joinChannel: 'Entrar no canal %s',
	cite: '%s cita:',
	urlDialog: 'Digite o endereço (URL) da página:',
	deleteMessage: 'Excluir esta mensagem',
	deleteMessageConfirm: 'Realmente apagar a mensagem selecionada chat?',
	errorCookiesRequired: 'Os cookies são requeridas para este Chat.',
	errorUserNameNotFound: 'Erro: Usuário %s não encontrado.',
	errorMissingText: 'Erro: Faltando mensagem texto.',
	errorMissingUserName: 'Erro: Usuário faltando.',
	errorInvalidUserName: 'Erro: Usuário inválido.',
	errorUserNameInUse: 'Erro: Usuário já em uso.',
	errorMissingChannelName: 'Erro: Nome do canal faltando.',
	errorInvalidChannelName: 'Erro: Nome do canal inválido: %s',
	errorPrivateMessageNotAllowed: 'Erro: Mensagens privadas não são permitidas.',
	errorInviteNotAllowed: 'Erro: Você não tem permissão para convidar alguém para este canal.',
	errorUninviteNotAllowed: 'Erro: Você não está autorizado a desconvidar alguém deste canal.',
	errorNoOpenQuery: 'Erro: Nenhum canal privado aberto.',
	errorKickNotAllowed: 'Erro: Você não está autorizado a kickar %s.',
	errorCommandNotAllowed: 'Erro: Comando não permitido: %s',
	errorUnknownCommand: 'Erro: Comando desconhecido: %s',
	errorMaxMessageRate: 'Erro: Você excedeu o número máximo de mensagens por minuto.',
	errorConnectionTimeout: 'Erro: Intervalo de parada da conexão. Por favor, tente novamente..',
	errorConnectionStatus: 'Erro: Status da conexão: %s',
	errorSoundIO: 'Erro: Falha ao carregar som arquivo (Flash IO Error).',
	errorSocketIO: 'Erro: Conexão para socket servidor falhou (Flash IO Error).',
	errorSocketSecurity: 'Erro: Conexão para socket servidor falhou (Flash Security Error).',
	errorDOMSyntax: 'Erro: Inválido DOM Syntax (DOM ID: %s).'

}