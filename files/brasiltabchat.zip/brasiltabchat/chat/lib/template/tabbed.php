<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<head>

	<script type="text/javascript">
	// Preload Tab Images
	if (document.images) {
		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_left_active.png';
		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_right_active.png';

		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_left_inactive.png';
		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_right_inactive.png';

		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_left_over.png';
		var preload_image_object = new Image();
		preload_image_object.src = '[AJAX_CHAT_URL/]images/tab_right_over.png';
	}
	</script>

	<meta http-equiv="Content-Type" content="[CONTENT_TYPE/]" />
	<title>[LANG]title[/LANG]</title>
	<style type="text/css">
		body {
			padding:0;
			margin:10;
		}

		iframe {
			position:absolute;
			left:0px;
			height:100%;
			width: 100%;
		}
	</style>
	[STYLE_SHEETS/]
	<!--[if lt IE 7]>
		<link rel="stylesheet" type="text/css" href="css/ie5-6.css"/>
		<script type="text/javascript">
			var isIElt7 = true;
		</script>
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="css/tab-view.css"/>
	<script type="text/javascript" src="js/php.js"></script>
	<script type="text/javascript" src="js/ajax.js"></script>
	<script type="text/javascript" src="js/tab-view.js"></script>

	<script src="js/chat.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/custom.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/lang/[LANG_CODE/].js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/config.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/FABridge.js" type="text/javascript" charset="UTF-8"></script>
	<script type="text/javascript">
		// <![CDATA[
			function toggleContainer(containerID, hideContainerIDs) {
				if (hideContainerIDs) {
					for(var i=0; i<hideContainerIDs.length; i++) {
						ajaxChat.showHide(hideContainerIDs[i], 'none');	
					}
				}		
				ajaxChat.showHide(containerID);
				if (typeof arguments.callee.styleProperty == 'undefined') {
					if(typeof isIElt7 != 'undefined') {
						arguments.callee.styleProperty = 'marginRight';
					} else {
						arguments.callee.styleProperty = 'right';
					}
				}
				var containerWidth = document.getElementById(containerID).offsetWidth;
				if(containerWidth) {
					document.getElementById('chatList').style[arguments.callee.styleProperty] = (containerWidth+28)+'px';	
				} else {
					document.getElementById('chatList').style[arguments.callee.styleProperty] = '20px';
				}				
			}

			function initialize() {
				ajaxChat.updateButton('audio', 'audioButton');
				ajaxChat.updateButton('autoScroll', 'autoScrollButton');
				for(var i=0; i<document.getElementById('audioVolumeSetting').options.length; i++) {
					if(document.getElementById('audioVolumeSetting').options[i].value == ajaxChat.getSetting('audioVolume')) {
						document.getElementById('audioVolumeSetting').options[i].selected = true;
						break;
					}
				}
				for (var i = 0; i <= document.getElementById('audioVolumeLocation').length-1; i++) {
					if(document.getElementById('audioVolumeLocation').options[i].value == ajaxChat.getSetting('audioLocation')){
						document.getElementById('audioVolumeLocation').options[i].selected = true;
						break;
					}
				}
				ajaxChat.fillSoundSelection('soundReceiveSetting', ajaxChat.getSetting('soundReceive'));
				ajaxChat.fillSoundSelection('soundSendSetting', ajaxChat.getSetting('soundSend'));
				ajaxChat.fillSoundSelection('soundEnterSetting', ajaxChat.getSetting('soundEnter'));
				ajaxChat.fillSoundSelection('soundLeaveSetting', ajaxChat.getSetting('soundLeave'));
				ajaxChat.fillSoundSelection('soundChatBotSetting', ajaxChat.getSetting('soundChatBot'));
				ajaxChat.fillSoundSelection('soundErrorSetting', ajaxChat.getSetting('soundError'));
				document.getElementById('fontColorSelected').style.background = ajaxChat.getSetting('fontColorCurrUser');
				ajaxChat.fillFontSelection('fontStyleSetting', ajaxChat.getSetting('fontStyleCurrUser'));
				ajaxChat.fillFontSelection('fontWeightSetting', ajaxChat.getSetting('fontWeightCurrUser'));
				ajaxChat.fillFontSelection('fontDecorationSetting', ajaxChat.getSetting('fontDecorationCurrUser'));
			}

			ajaxChatConfig.chatCurrUser = '[AJAX_USER_CURRUSER/]';
			ajaxChatConfig.isInTab = false;

			ajaxChatConfig.loginChannelID = parseInt('[LOGIN_CHANNEL_ID/]');
			ajaxChatConfig.sessionName = '[SESSION_NAME/]';
			ajaxChatConfig.cookieExpiration = parseInt('[COOKIE_EXPIRATION/]');
			ajaxChatConfig.cookiePath = '[COOKIE_PATH/]';
			ajaxChatConfig.cookieDomain = '[COOKIE_DOMAIN/]';
			ajaxChatConfig.cookieSecure = '[COOKIE_SECURE/]';
			ajaxChatConfig.chatBotName = decodeURIComponent('[CHAT_BOT_NAME/]');
			ajaxChatConfig.chatBotID = '[CHAT_BOT_ID/]';
			ajaxChatConfig.allowUserMessageDelete = parseInt('[ALLOW_USER_MESSAGE_DELETE/]');
			ajaxChatConfig.inactiveTimeout = parseInt('[INACTIVE_TIMEOUT/]');
			ajaxChatConfig.privateChannelDiff = parseInt('[PRIVATE_CHANNEL_DIFF/]');
			ajaxChatConfig.privateMessageDiff = parseInt('[PRIVATE_MESSAGE_DIFF/]');
			ajaxChatConfig.showChannelMessages = parseInt('[SHOW_CHANNEL_MESSAGES/]');
			ajaxChatConfig.messageTextMaxLength = parseInt('[MESSAGE_TEXT_MAX_LENGTH/]');
			ajaxChatConfig.socketServerEnabled = parseInt('[SOCKET_SERVER_ENABLED/]');
			ajaxChatConfig.socketServerHost = decodeURIComponent('[SOCKET_SERVER_HOST/]');
			ajaxChatConfig.socketServerPort = parseInt('[SOCKET_SERVER_PORT/]');
			ajaxChatConfig.socketServerChatID = parseInt('[SOCKET_SERVER_CHAT_ID/]');
		
			ajaxChat.init(ajaxChatConfig, ajaxChatLang, true, true, true, initialize);
		// ]]>
	</script>
</head>

<body>

<div id="DIVabas" style="position:absolute;">

	<div class="dhtmlgoodies_aTab">

	<div id="content">

		<div id="headlineContainer">
			<h1>[LANG]title[/LANG]</h1>
		</div>
		<div id="logoutChannelContainer">
  			<input type="button" id="logoutButton" value="[LANG]logout[/LANG]" onclick="ajaxChat.logout();" style="cursor:pointer;"/>
			<label for="channelSelection">[LANG]channel[/LANG]:</label>
			<select id="channelSelection" onchange="ajaxChat.switchChannel(this.options[this.selectedIndex].value);">[CHANNEL_OPTIONS/]</select>
			<label for="styleSelection">[LANG]style[/LANG]:</label>
			<select id="styleSelection" onchange="ajaxChat.setActiveStyleSheet(ajaxChat.getSelectedStyle());">[STYLE_OPTIONS/]</select>
			<label for="languageSelection">[LANG]language[/LANG]:</label>
			<select id="languageSelection" onchange="ajaxChat.switchLanguage(this.value);">[LANGUAGE_OPTIONS/]</select>
  		</div>
		<div id="statusIconContainer" class="statusContainerOn" onclick="ajaxChat.updateChat(null);"></div>
		<!--[if lt IE 7]>
			<div></div>
		<![endif]-->
		<div id="chatList"></div>
		<div id="inputFieldContainer">
			<textarea id="inputField" rows="1" cols="50" title="[LANG]inputLineBreak[/LANG]" onkeypress="ajaxChat.handleInputFieldKeyPress(event);" onkeyup="ajaxChat.handleInputFieldKeyUp(event);"></textarea>
		</div>
		<div id="submitButtonContainer">
			<span id="messageLengthCounter">0/[MESSAGE_TEXT_MAX_LENGTH/]</span>
			<input type="button" id="submitButton" value="[LANG]messageSubmit[/LANG]" onclick="ajaxChat.sendMessage();" style="cursor:pointer;"/>
		</div>
		<div id="emoticonsContainer" dir="ltr"></div>
		<div id="bbCodeContainer">
			<input type="button" value="[LANG]bbCodeLabelBold[/LANG]" title="[LANG]bbCodeTitleBold[/LANG]" onclick="ajaxChat.insertBBCode('b');" style="font-weight:bold;"/>
			<input type="button" value="[LANG]bbCodeLabelItalic[/LANG]" title="[LANG]bbCodeTitleItalic[/LANG]" onclick="ajaxChat.insertBBCode('i');" style="font-style:italic;"/>
			<input type="button" value="[LANG]bbCodeLabelUnderline[/LANG]" title="[LANG]bbCodeTitleUnderline[/LANG]" onclick="ajaxChat.insertBBCode('u');" style="text-decoration:underline;"/>
			<input type="button" value="[LANG]bbCodeLabelQuote[/LANG]" title="[LANG]bbCodeTitleQuote[/LANG]" onclick="ajaxChat.insertBBCode('quote');"/>
			<input type="button" value="[LANG]bbCodeLabelCode[/LANG]" title="[LANG]bbCodeTitleCode[/LANG]" onclick="ajaxChat.insertBBCode('code');"/>
			<input type="button" value="[LANG]bbCodeLabelURL[/LANG]" title="[LANG]bbCodeTitleURL[/LANG]" onclick="ajaxChat.insertBBCode('url');"/>
			<input type="button" value="[LANG]bbCodeLabelImg[/LANG]" title="[LANG]bbCodeTitleImg[/LANG]" onclick="ajaxChat.insertBBCode('img');"/>
			<input type="button" value="[LANG]bbCodeLabelColor[/LANG]" title="[LANG]bbCodeTitleColor[/LANG]" onclick="ajaxChat.showHide('colorCodesContainer', null);"/>
		</div>
		<div id="colorCodesContainer" style="display:none;" dir="ltr"></div>
		<div id="optionsContainer">
			<input type="image" src="img/pixel.gif" class="button" id="settingsButton" alt="[LANG]toggleSettings[/LANG]" title="[LANG]toggleSettings[/LANG]" onclick="toggleContainer('settingsContainer', new Array('onlineListContainer','helpContainer'));"/>
			<input type="image" src="img/pixel.gif" class="button" id="onlineListButton" alt="[LANG]toggleOnlineList[/LANG]" title="[LANG]toggleOnlineList[/LANG]" onclick="toggleContainer('onlineListContainer', new Array('settingsContainer','helpContainer'));"/>
			<input type="image" src="img/pixel.gif" class="button" id="audioButton" alt="[LANG]toggleAudio[/LANG]" title="[LANG]toggleAudio[/LANG]" onclick="ajaxChat.toggleSetting('audio', 'audioButton');"/>
			<input type="image" src="img/pixel.gif" class="button" id="autoScrollButton" alt="[LANG]toggleAutoScroll[/LANG]" title="[LANG]toggleAutoScroll[/LANG]" onclick="ajaxChat.toggleSetting('autoScroll', 'autoScrollButton');"/>
  		</div>
		<div id="onlineListContainer">
			<h3>[LANG]onlineUsers[/LANG]</h3>
	  		<div id="onlineList"></div>
	  	</div>

	  	<div id="settingsContainer" style="display:none;">
 			<h3>[LANG]settings[/LANG]</h3>
 			<div id="settingsList">
				<span id="fontColorSettingContainer" style="display:none;" dir="ltr"></span>
				<table>

					<tr class="rowOdd">
						<td style="width:300px;"><label class="settingsLabel" for="fontColorSelected">[LANG]fontColorLabel[/LANG]</label></td>
						<td class="setting" style="width:22px;">
							<span id="fontColorSelected"></span>
						</td>
						<td class="setting">
							<span class="settingsLabel" style="cursor:pointer;" onclick="ajaxChat.showHide('fontColorSettingContainer', null);">[LANG]changeCustomFontColor[/LANG]</span>
						</td>
					</tr>

					<tr class="rowEven">
						<td><label class="settingsLabel" for="fontStyleSetting">[LANG]fontStyleLabel[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select style="width:130px;" id="fontStyleSetting" onchange="ajaxChat.setSetting('fontStyleCurrUser', this.options[this.selectedIndex].value);">
								<option value="normal">[LANG]fontStyleNormal[/LANG]</option>
								<option value="italic">[LANG]fontStyleItalic[/LANG]</option>
								<option value="oblique">[LANG]fontStyleOblique[/LANG]</option>
							</select>
						</td>
					</tr>

					<tr class="rowOdd">
						<td><label class="settingsLabel" for="fontWeightSetting">[LANG]fontWeightLabel[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select style="width:130px;" id="fontWeightSetting" onchange="ajaxChat.setSetting('fontWeightCurrUser', this.options[this.selectedIndex].value);">
								<option value="normal">[LANG]fontWeightNormal[/LANG]</option>
								<option value="lighter">[LANG]fontWeightLighter[/LANG]</option>
								<option value="bold">[LANG]fontWeightBold[/LANG]</option>
								<option value="bolder">[LANG]fontWeightBolder[/LANG]</option>
							</select>
						</td>
					</tr>

					<tr class="rowEven">
						<td><label class="settingsLabel" for="fontDecorationSetting">[LANG]fontDecorationLabel[/LANG]</label></td>
						<td class="setting"  colspan="2">
							<select style="width:130px;" id="fontDecorationSetting" onchange="ajaxChat.setSetting('fontDecorationCurrUser', this.options[this.selectedIndex].value);">
								<option value="none">[LANG]fontDecorationNone[/LANG]</option>
								<option value="underline">[LANG]fontDecorationUnderline[/LANG]</option>
								<option value="line-through">[LANG]fontDecorationLineThrough[/LANG]</option>
								<option value="overline">[LANG]fontDecorationOverline[/LANG]</option>
							</select>
						</td>
					</tr>

					<tr class="rowOdd">
						<td><label class="settingsLabel" for="audioVolumeLocation">[LANG]audioLocationLabel[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select style="width:130px;" id="audioVolumeLocation" onchange="ajaxChat.setSetting('audioLocation', this.options[this.selectedIndex].value);">
								<option value="all">[LANG]audioLocationAll[/LANG]</option>
								<option value="main">[LANG]audioLocationMain[/LANG]</option>
								<option value="tabs">[LANG]audioLocationTabs[/LANG]</option>
							</select>
						</td>
					</tr>

					<tr class="rowEven">
						<td><label class="settingsLabel" for="audioVolumeSetting">[LANG]settingsAudioVolume[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select style="width:130px;" id="audioVolumeSetting" onchange="ajaxChat.setAudioVolume(this.options[this.selectedIndex].value);">
								<option value="1.0">100 %</option>
								<option value="0.9">90 %</option>
								<option value="0.8">80 %</option>
								<option value="0.7">70 %</option>
								<option value="0.6">60 %</option>
								<option value="0.5">50 %</option>
								<option value="0.4">40 %</option>
								<option value="0.3">30 %</option>
								<option value="0.2">20 %</option>
								<option value="0.1">10 %</option>
							</select>
						</td>
					</tr>
					<tr class="rowOdd">
						<td><label class="settingsLabel" for="soundReceiveSetting">[LANG]settingsSoundReceive[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundReceiveSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundReceive', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
					<tr class="rowEven">
						<td><label class="settingsLabel" for="soundSendSetting">[LANG]settingsSoundSend[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundSendSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundSend', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
					<tr class="rowOdd">
						<td><label class="settingsLabel" for="soundEnterSetting">[LANG]settingsSoundEnter[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundEnterSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundEnter', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
					<tr class="rowEven">
						<td><label class="settingsLabel" for="soundLeaveSetting">[LANG]settingsSoundLeave[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundLeaveSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundLeave', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
					<tr class="rowOdd">
						<td><label class="settingsLabel" for="soundChatBotSetting">[LANG]settingsSoundChatBot[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundChatBotSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundChatBot', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
					<tr class="rowEven">
						<td><label class="settingsLabel" for="soundErrorSetting">[LANG]settingsSoundError[/LANG]</label></td>
						<td class="setting" colspan="2">
							<select id="soundErrorSetting" style="width:110px;" onchange="ajaxChat.setSetting('soundError', this.options[this.selectedIndex].value);"><option value="">-</option></select><input type="image" src="img/pixel.gif" class="button playback" alt="[LANG]playSelectedSound[/LANG]" title="[LANG]playSelectedSound[/LANG]" onclick="ajaxChat.playSound(this.previousSibling.options[this.previousSibling.selectedIndex].value);"/>
						</td>
					</tr>
				</table>
			</div>
	  	</div>
		<div id="copyright"><a href=http://www.wdwebdesign.com.br/ target=_blank>WD WebDesign</a></div>
	</div>

	</div>
</div>

<script type="text/javascript">
initTabs('DIVabas',Array('Chat'),0,743,470,Array(false));
</script>

	<div id="flashInterfaceContainer"></div>

</body>

</html>