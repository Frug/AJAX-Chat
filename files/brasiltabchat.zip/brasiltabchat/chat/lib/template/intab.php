<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">

<head>
	<meta http-equiv="Content-Type" content="[CONTENT_TYPE/]" />
	<title>[LANG]title[/LANG]</title>
	<style type="text/css">
		body {
			padding:0;
			margin:0;
		}
	</style>
	[STYLE_SHEETS/]
	<!--[if lt IE 7]>
		<link rel="stylesheet" type="text/css" href="css/ie5-6.css"/>
		<script type="text/javascript">
			var isIElt7 = true;
		</script>
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="css/tab-view.css"/>

	<script src="js/chat.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/custom.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/lang/[LANG_CODE/].js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/config.js" type="text/javascript" charset="UTF-8"></script>
	<script src="js/FABridge.js" type="text/javascript" charset="UTF-8"></script>
	<script type="text/javascript">
		// <![CDATA[
			function toggleContainer(containerID, hideContainerIDs) {
				if (hideContainerIDs) {
					for(var i=0; i<hideContainerIDs.length; i++) {
						ajaxChat.showHide(hideContainerIDs[i], 'none');
					}
				}
				ajaxChat.showHide(containerID);
				if (typeof arguments.callee.styleProperty == 'undefined') {
					if(typeof isIElt7 != 'undefined') {
						arguments.callee.styleProperty = 'marginRight';
					} else {
						arguments.callee.styleProperty = 'right';
					}
				}
				var containerWidth = document.getElementById(containerID).offsetWidth;
				if(containerWidth) {
					document.getElementById('chatList').style[arguments.callee.styleProperty] = (containerWidth+28)+'px';
				} else {
					document.getElementById('chatList').style[arguments.callee.styleProperty] = '20px';
				}				
			}

			function initialize() {
				ajaxChat.updateButton('autoScroll', 'autoScrollButton');
			}

			ajaxChatConfig.chatReceiver = '[AJAX_USER_RECEIVER/]';
			ajaxChatConfig.chatCurrUser = '[AJAX_USER_CURRUSER/]';
			ajaxChatConfig.isInTab = true;

			ajaxChatConfig.loginChannelID = parseInt('[LOGIN_CHANNEL_ID/]');
			ajaxChatConfig.sessionName = '[SESSION_NAME/]';
			ajaxChatConfig.cookieExpiration = parseInt('[COOKIE_EXPIRATION/]');
			ajaxChatConfig.cookiePath = '[COOKIE_PATH/]';
			ajaxChatConfig.cookieDomain = '[COOKIE_DOMAIN/]';
			ajaxChatConfig.cookieSecure = '[COOKIE_SECURE/]';
			ajaxChatConfig.chatBotName = decodeURIComponent('[CHAT_BOT_NAME/]');
			ajaxChatConfig.chatBotID = '[CHAT_BOT_ID/]';
			ajaxChatConfig.allowUserMessageDelete = parseInt('[ALLOW_USER_MESSAGE_DELETE/]');
			ajaxChatConfig.inactiveTimeout = parseInt('[INACTIVE_TIMEOUT/]');
			ajaxChatConfig.privateChannelDiff = parseInt('[PRIVATE_CHANNEL_DIFF/]');
			ajaxChatConfig.privateMessageDiff = parseInt('[PRIVATE_MESSAGE_DIFF/]');
			ajaxChatConfig.showChannelMessages = parseInt('[SHOW_CHANNEL_MESSAGES/]');
			ajaxChatConfig.messageTextMaxLength = parseInt('[MESSAGE_TEXT_MAX_LENGTH/]');
			ajaxChatConfig.socketServerEnabled = parseInt('[SOCKET_SERVER_ENABLED/]');
			ajaxChatConfig.socketServerHost = decodeURIComponent('[SOCKET_SERVER_HOST/]');
			ajaxChatConfig.socketServerPort = parseInt('[SOCKET_SERVER_PORT/]');
			ajaxChatConfig.socketServerChatID = parseInt('[SOCKET_SERVER_CHAT_ID/]');

			ajaxChat.init(ajaxChatConfig, ajaxChatLang, true, true, true, initialize);
		// ]]>
	</script>
</head>

<body>

	<div id="content">


		<div id="headlineContainer">
			<h1>[LANG]title[/LANG] - [AJAX_USER_RECEIVER/]</h1>
		</div>
		<div id="logoutChannelContainer">
  			<input type="button" id="logoutButton" value="[LANG]logout[/LANG]" onclick="ajaxChat.logout();" style="cursor:pointer;"/>
			<label for="styleSelection">[LANG]style[/LANG]:</label>
			<select id="styleSelection" onchange="ajaxChat.setActiveStyleSheet(ajaxChat.getSelectedStyle());" style="cursor:pointer;">[STYLE_OPTIONS/]</select>
  		</div>
		<div id="statusIconContainer" class="statusContainerOn" onclick="ajaxChat.updateChat(null);"></div>
		<!--[if lt IE 7]>
			<div></div>
		<![endif]-->
		<div id="chatList" style="right:20px;"></div>

		<div id="inputFieldContainer">
			<textarea id="inputField" rows="1" cols="50" title="[LANG]inputLineBreak[/LANG]" onkeypress="ajaxChat.handleInputFieldKeyPress(event);" onkeyup="ajaxChat.handleInputFieldKeyUp(event);"></textarea>
		</div>
		<div id="submitButtonContainer">
			<span id="messageLengthCounter">0/[MESSAGE_TEXT_MAX_LENGTH/]</span>
			<input type="button" id="submitButton" value="[LANG]messageSubmit[/LANG]" onclick="ajaxChat.sendMessage();" style="cursor:pointer;"/>
		</div>
		<div id="emoticonsContainer" dir="ltr"></div>
		<div id="bbCodeContainer">
			<input type="button" value="[LANG]bbCodeLabelBold[/LANG]" title="[LANG]bbCodeTitleBold[/LANG]" onclick="ajaxChat.insertBBCode('b');" style="font-weight:bold;"/>
			<input type="button" value="[LANG]bbCodeLabelItalic[/LANG]" title="[LANG]bbCodeTitleItalic[/LANG]" onclick="ajaxChat.insertBBCode('i');" style="font-style:italic;"/>
			<input type="button" value="[LANG]bbCodeLabelUnderline[/LANG]" title="[LANG]bbCodeTitleUnderline[/LANG]" onclick="ajaxChat.insertBBCode('u');" style="text-decoration:underline;"/>
			<input type="button" value="[LANG]bbCodeLabelQuote[/LANG]" title="[LANG]bbCodeTitleQuote[/LANG]" onclick="ajaxChat.insertBBCode('quote');"/>
			<input type="button" value="[LANG]bbCodeLabelCode[/LANG]" title="[LANG]bbCodeTitleCode[/LANG]" onclick="ajaxChat.insertBBCode('code');"/>
			<input type="button" value="[LANG]bbCodeLabelURL[/LANG]" title="[LANG]bbCodeTitleURL[/LANG]" onclick="ajaxChat.insertBBCode('url');"/>
			<input type="button" value="[LANG]bbCodeLabelImg[/LANG]" title="[LANG]bbCodeTitleImg[/LANG]" onclick="ajaxChat.insertBBCode('img');"/>
			<input type="button" value="[LANG]bbCodeLabelColor[/LANG]" title="[LANG]bbCodeTitleColor[/LANG]" onclick="ajaxChat.showHide('colorCodesContainer', null);"/>
		</div>
		<div id="colorCodesContainer" style="display:none;" dir="ltr"></div>
		<div id="optionsContainer">
			<input type="image" src="img/pixel.gif" class="button" id="autoScrollButton" alt="[LANG]toggleAutoScroll[/LANG]" title="[LANG]toggleAutoScroll[/LANG]" onclick="ajaxChat.toggleSetting('autoScroll', 'autoScrollButton');"/>
  		</div>

		<div id="isTypingContainer" style="display:none;"></div>

		<div id="copyright"><a href=http://www.wdwebdesign.com.br/ target=_blank>WD WebDesign</a></div>
	</div>

	<div id="flashInterfaceContainer"></div>

</body>

</html>