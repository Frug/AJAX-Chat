<?php
/*
 * @package AJAX_Chat
 * @author Sebastian Tschan
 * @copyright (c) Sebastian Tschan
 * @license GNU Affero General Public License
 * @link https://blueimp.net/ajax/
 * @tabs mod by bccsergio - http://www.wdwebdesign.com.br/ - http://www.wdwebdesign.com.br/new/chat/
 */

// Show all errors:
error_reporting(E_ALL);

$receiver = isset($_REQUEST['receiver']) ? $_REQUEST['receiver'] : null;
if ($receiver) {
	define('AJAX_USER_RECEIVER', $receiver);
}

// To receive custom avatar, uncomment this:
/*
$avatar = isset($_REQUEST['avatar']) ? $_REQUEST['avatar'] : null;
if ($avatar) {
	define('AJAX_USER_AVATAR', $avatar);
}
*/

// Path to the chat directory:
define('AJAX_CHAT_PATH', dirname($_SERVER['SCRIPT_FILENAME']).'/');

// Include custom libraries and initialization code:
require(AJAX_CHAT_PATH.'lib/custom.php');

// Include Class libraries:
require(AJAX_CHAT_PATH.'lib/classes.php');

// Initialize the chat:
$ajaxChat = new CustomAJAXChat();
?>